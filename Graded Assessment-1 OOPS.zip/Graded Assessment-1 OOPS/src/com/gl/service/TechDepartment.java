package com.gl.service;

public class TechDepartment extends SuperDepartment {
	
	public String departmentName() {
		
		return "Tech Department";
	}
	
	public String getTodaysWork() {
		
		return "Complete Coding of module 1";
	}
	
	public String  getWorkDeadline(){
		
		return "Complete by EOD";
	}
	
	public String getTechStackInformation() {
		
		return "core Java";
	}

}
